﻿var app = angular.module('customersApp', [ 'ngRoute' ]);

app.config(function($routeProvider) {
	$routeProvider.when('/notes', {
		controller : 'CustomersController',
		templateUrl : './static/app/partials/notes.html'
	}).when('/labels', {
		controller : 'CustomersController',
		templateUrl : './static/app/partials/labels.html'
	}).when('/customerorders/:customerID', {
		controller : 'CustomerOrdersController',
		templateUrl : './static/app/partials/customerOrders.html'
	}).when('/orders', {
		controller : 'OrdersController',
		templateUrl : './static/app/partials/orders.html'
	}).otherwise({
		redirectTo : '/notes'
	});
});
