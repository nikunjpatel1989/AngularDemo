package com.todo.service;

import java.util.List;

import com.todo.model.UserData;

public interface UserDataService {
	
	UserData findById(long id);
	
	UserData findByName(String name);
	
	void saveUser(UserData user);
	
	void updateUser(UserData user);
	
	void deleteUserById(long id);

	List<UserData> findAllUsers(); 
	
	void deleteAllUsers();
	
	public boolean isUserExist(UserData user);
	
}
