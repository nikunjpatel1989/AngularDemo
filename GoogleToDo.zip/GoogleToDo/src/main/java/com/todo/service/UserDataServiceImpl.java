package com.todo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.todo.model.UserData;

@Service("userDataService")
public class UserDataServiceImpl implements UserDataService {

	@Override
	public UserData findById(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserData findByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveUser(UserData user) {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateUser(UserData user) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteUserById(long id) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<UserData> findAllUsers() {
		List<UserData> li = new ArrayList<>();
		UserData u1 = new UserData(1, "Title1", "Note1", "Label1", "Collob1");
		UserData u2 = new UserData(2, "Title2", "Note2", "Label2", "Collob2");
		UserData u3 = new UserData(3, "Title3", "Note3", "Label3", "Collob3");
		UserData u4 = new UserData(4, "Title4", "Note4", "Label4", "Collob4");
		li.add(u1);
		li.add(u2);
		li.add(u3);
		li.add(u4);

		return li;
	}

	@Override
	public void deleteAllUsers() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean isUserExist(UserData user) {
		// TODO Auto-generated method stub
		return false;
	}
}
