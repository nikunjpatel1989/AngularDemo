package com.todo.model;

public class UserData {

	private long id;
	private String title;
	private String note;
	private String label;
	private String collobarator;

	public UserData(long id, String title, String note, String label, String collobarator) {
		super();
		this.id = id;
		this.title = title;
		this.note = note;
		this.label = label;
		this.collobarator = collobarator;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getCollobarator() {
		return collobarator;
	}

	public void setCollobarator(String collobarator) {
		this.collobarator = collobarator;
	}

	@Override
	public String toString() {
		return "UserData [id=" + id + ", title=" + title + ", note=" + note + ", label=" + label + ", collobarator="
				+ collobarator + "]";
	}

}
