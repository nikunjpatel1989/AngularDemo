package com.todo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.todo.model.UserData;
import com.todo.service.UserDataService;

@RestController
public class UserController {

	@Autowired
	UserDataService userService;

	
	@RequestMapping(value = "/user/", method = RequestMethod.GET)
	public ResponseEntity<List<UserData>> listAllUsers() {
		List<UserData> users = userService.findAllUsers();
		if (users.isEmpty()) {
			return new ResponseEntity<List<UserData>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<UserData>>(users, HttpStatus.OK);
	}

	// -------------------Retrieve Single
	// UserData--------------------------------------------------------

	@RequestMapping(value = "/user/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserData> getUser(@PathVariable("id") long id) {
		System.out.println("Fetching UserData with id " + id);
		UserData user = userService.findById(id);
		if (user == null) {
			System.out.println("UserData with id " + id + " not found");
			return new ResponseEntity<UserData>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<UserData>(user, HttpStatus.OK);
	}

	// -------------------Create a
	// UserData--------------------------------------------------------

	@RequestMapping(value = "/user/", method = RequestMethod.POST)
	public ResponseEntity<Void> createUser(@RequestBody UserData user, UriComponentsBuilder ucBuilder) {

		if (userService.isUserExist(user)) {
			return new ResponseEntity<Void>(HttpStatus.CONFLICT);
		}

		userService.saveUser(user);

		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(ucBuilder.path("/user/{id}").buildAndExpand(user.getId()).toUri());
		return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	}

	// ------------------- Update a UserData
	// --------------------------------------------------------

	@RequestMapping(value = "/user/{id}", method = RequestMethod.PUT)
	public ResponseEntity<UserData> updateUser(@PathVariable("id") long id, @RequestBody UserData user) {
		System.out.println("Updating UserData " + id);

		UserData currentUser = userService.findById(id);

		if (currentUser == null) {
			System.out.println("UserData with id " + id + " not found");
			return new ResponseEntity<UserData>(HttpStatus.NOT_FOUND);
		}

//		currentUser.setUsername(user.getUsername());
//		currentUser.setAddress(user.getAddress());
//		currentUser.setEmail(user.getEmail());

		userService.updateUser(currentUser);
		return new ResponseEntity<UserData>(currentUser, HttpStatus.OK);
	}

	// ------------------- Delete a UserData
	// --------------------------------------------------------

	@RequestMapping(value = "/user/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<UserData> deleteUser(@PathVariable("id") long id) {
		System.out.println("Fetching & Deleting UserData with id " + id);

		UserData user = userService.findById(id);
		if (user == null) {
			System.out.println("Unable to delete. UserData with id " + id + " not found");
			return new ResponseEntity<UserData>(HttpStatus.NOT_FOUND);
		}

		userService.deleteUserById(id);
		return new ResponseEntity<UserData>(HttpStatus.NO_CONTENT);
	}

	// ------------------- Delete All Users
	// --------------------------------------------------------

	@RequestMapping(value = "/user/", method = RequestMethod.DELETE)
	public ResponseEntity<UserData> deleteAllUsers() {
		System.out.println("Deleting All Users");

		userService.deleteAllUsers();
		return new ResponseEntity<UserData>(HttpStatus.NO_CONTENT);
	}

}